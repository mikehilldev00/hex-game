# Development Notes
This version of Hex 2048 is no longer maintained. If development on this project
restarts, it most likely will involve a complete rewrite to move away from the
Phaser framework.

## Dependencies
The code has a local copy of Phaser 2.5.0. Please refer to the appropriate docs
when developing.
